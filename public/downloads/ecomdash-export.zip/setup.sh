#!/usr/bin/env bash
# ============================================================
# EcomDash - Script de instalación rápida (Linux / macOS)
# ============================================================
# Uso: ./setup.sh
# Este script instala dependencias, genera Prisma, sincroniza
# el esquema de la base de datos y carga los datos iniciales.

set -e

echo "🚀 EcomDash - Instalación automática"
echo "===================================="

cd "$(dirname "$0")/ecomdash"

# 1. Verificar .env
if [ ! -f .env ]; then
  echo "📋 Copiando .env.example -> .env (edítalo con tus datos)"
  cp .env.example .env
  echo ""
  echo "⚠️  IMPORTANTE: Edita el archivo ecomdash/.env con tus datos"
  echo "    de conexión PostgreSQL antes de continuar."
  echo ""
  read -p "Presiona ENTER cuando hayas editado .env (o CTRL+C para salir)..."
fi

# 2. Instalar dependencias
echo ""
echo "📦 Instalando dependencias (puede tardar 1-3 min)..."
yarn install

# 3. Generar cliente Prisma
echo ""
echo "🔧 Generando cliente Prisma..."
yarn db:generate

# 4. Sincronizar esquema con la BD
echo ""
echo "📊 Creando tablas en PostgreSQL..."
yarn db:push

# 5. Sembrar datos iniciales
echo ""
echo "🌱 Cargando datos de ejemplo..."
yarn db:seed

echo ""
echo "✅ ¡Listo! Inicia el servidor con:"
echo ""
echo "    cd ecomdash && yarn dev"
echo ""
echo "Y abre http://localhost:3000 en tu navegador."
echo ""
echo "🔑 Credenciales admin: admin@ecomdash.com / admin123"
