@echo off
REM ============================================================
REM EcomDash - Script de instalacion rapida (Windows)
REM ============================================================
REM Uso: setup.bat (doble click o desde CMD)

echo.
echo EcomDash - Instalacion automatica
echo ====================================

cd /d "%~dp0\ecomdash"

REM 1. Verificar .env
if not exist .env (
  echo Copiando .env.example -^> .env
  copy .env.example .env
  echo.
  echo IMPORTANTE: Edita el archivo ecomdash\.env con tus datos
  echo de conexion PostgreSQL antes de continuar.
  echo.
  pause
)

REM 2. Instalar dependencias
echo.
echo Instalando dependencias (puede tardar 1-3 min)...
call yarn install
if %errorlevel% neq 0 goto error

REM 3. Generar cliente Prisma
echo.
echo Generando cliente Prisma...
call yarn db:generate
if %errorlevel% neq 0 goto error

REM 4. Sincronizar esquema
echo.
echo Creando tablas en PostgreSQL...
call yarn db:push
if %errorlevel% neq 0 goto error

REM 5. Sembrar datos
echo.
echo Cargando datos de ejemplo...
call yarn db:seed
if %errorlevel% neq 0 goto error

echo.
echo Listo! Inicia el servidor con:
echo.
echo    cd ecomdash
echo    yarn dev
echo.
echo Y abre http://localhost:3000 en tu navegador.
echo.
echo Credenciales admin: admin@ecomdash.com / admin123
pause
exit /b 0

:error
echo.
echo Error durante la instalacion. Revisa los mensajes anteriores.
pause
exit /b 1
