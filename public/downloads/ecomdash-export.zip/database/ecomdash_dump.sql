--
-- PostgreSQL database dump
--


-- Dumped from database version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public."Order" DROP CONSTRAINT IF EXISTS "Order_userId_fkey";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."Setting_key_key";
DROP INDEX IF EXISTS public."Product_isActive_idx";
DROP INDEX IF EXISTS public."Product_categoryId_idx";
DROP INDEX IF EXISTS public."Order_userId_idx";
DROP INDEX IF EXISTS public."Order_status_idx";
DROP INDEX IF EXISTS public."Category_slug_key";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."Setting" DROP CONSTRAINT IF EXISTS "Setting_pkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_pkey";
ALTER TABLE IF EXISTS ONLY public."Order" DROP CONSTRAINT IF EXISTS "Order_pkey";
ALTER TABLE IF EXISTS ONLY public."Category" DROP CONSTRAINT IF EXISTS "Category_pkey";
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."Setting";
DROP TABLE IF EXISTS public."Product";
DROP TABLE IF EXISTS public."Order";
DROP TABLE IF EXISTS public."Category";
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."OrderStatus";
--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'SHIPPED',
    'DELIVERED',
    'CANCELLED'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'SUPERADMIN',
    'ADMIN',
    'CLIENTE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Category" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    icon text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "userId" text,
    items jsonb NOT NULL,
    total double precision NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "whatsappSent" boolean DEFAULT false NOT NULL,
    "customerName" text,
    "customerPhone" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price double precision NOT NULL,
    "originalPrice" double precision,
    discount integer,
    rating double precision DEFAULT 0 NOT NULL,
    "soldCount" integer DEFAULT 0 NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    "imageUrl" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isFlashSale" boolean DEFAULT false NOT NULL,
    "categoryId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Setting" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."Role" DEFAULT 'CLIENTE'::public."Role" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Category" (id, name, slug, icon, "createdAt") FROM stdin;
cmot619xh0006q2ysvnyv792q	Camisetas	camisetas	Shirt	2026-05-05 21:54:02.501
cmot619xj0007q2ysh3stmnd3	Chaquetas	chaquetas	Wind	2026-05-05 21:54:02.503
cmot619xl0008q2ysnrntrivq	Camisas	camisas	Layers	2026-05-05 21:54:02.505
cmot619xo0009q2yshlbl7sbx	Jeans	jeans	Ruler	2026-05-05 21:54:02.508
cmot619xq000aq2ysyj5hg4ra	Bolsos	bolsos	ShoppingBag	2026-05-05 21:54:02.511
cmot619xs000bq2ys5a8na0qv	Zapatos	zapatos	Footprints	2026-05-05 21:54:02.512
\.


--
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Order" (id, "userId", items, total, status, "whatsappSent", "customerName", "customerPhone", notes, "createdAt", "updatedAt") FROM stdin;
cmot7i8wq0005rv08od5jxxg9	cmot619x20000q2yshsvxexxr	[{"id": "chaqueta-bomber-invierno", "name": "Chaqueta Bomber Invierno", "price": 199000, "imageUrl": "https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2", "quantity": 1}]	199000	PENDING	t	Administrador	\N	\N	2026-05-05 22:35:13.945	2026-05-05 22:35:13.945
cmot7juhc000brv08kqqtd2l3	cmot619x20000q2yshsvxexxr	[{"id": "chaqueta-bomber-invierno", "name": "Chaqueta Bomber Invierno", "price": 199000, "imageUrl": "https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2", "quantity": 1}]	199000	PENDING	t	Administrador	\N	\N	2026-05-05 22:36:28.561	2026-05-05 22:36:28.561
cmot7koal000drv08yc74oynt	cmot619x20000q2yshsvxexxr	[{"id": "camiseta-algodon-casual", "name": "Camiseta de Algodón Casual", "price": 59000, "imageUrl": "https://skims.imgix.net/s/files/1/0259/5448/4284/files/SKIMS-LOUNGEWEAR-TP-TSH-5701M-CHK.jpg?v=1738175705&auto=format&q=70&ixlib=react-9.11.0", "quantity": 1}]	59000	PENDING	t	Administrador	\N	\N	2026-05-05 22:37:07.198	2026-05-05 22:37:07.198
cmot7fitw0003rv08fiytpgkw	\N	[{"id": "chaqueta-bomber-invierno", "name": "Chaqueta Bomber Invierno", "price": 199000, "imageUrl": "https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2", "quantity": 10}]	1990000	CANCELLED	t	Wilmer	3044444261	\N	2026-05-05 22:33:06.836	2026-05-05 23:05:34.509
cmot7ectf0001rv081g513f8d	\N	[{"id": "camisa-elegante-rayas", "name": "Camisa Elegante a Rayas", "price": 129000, "imageUrl": "http://www.nimble-made.com/cdn/shop/products/new-striped-blue-white-dress-shirt_9bf4f99c-3308-4910-b57a-d118fb953134.jpg?v=1670899180", "quantity": 1}, {"id": "oxford-cuero-negro", "name": "Zapatos Oxford de Cuero Negro", "price": 259000, "imageUrl": "https://taftclothing.com/cdn/shop/products/Jack_Black_cropped.jpg?v=1762439486&width=1000", "quantity": 2}, {"id": "bolso-tote-cuero", "name": "Bolso Tote de Cuero", "price": 289000, "imageUrl": "https://latelierglobal.com/cdn/shop/products/olimpia-leather-tote-608292.jpg?v=1737917924&width=2048", "quantity": 1}, {"id": "sandalias-tacon-gris", "name": "Sandalias de Tacón Gris", "price": 179000, "imageUrl": "https://www.piccolashoes.com/cdn/shop/products/joyce-grey-open-toe-heels.png?v=1761084095&width=1024", "quantity": 1}]	1115000	DELIVERED	t	\N	\N	\N	2026-05-05 22:32:12.387	2026-05-05 22:50:11.487
cmot8mqst000frv08pv3ti8cr	cmot619x20000q2yshsvxexxr	[{"id": "jeans-slim-fit-azul", "name": "Jeans Slim Fit Azul", "price": 149000, "imageUrl": "https://media.istockphoto.com/id/173239968/photo/skinny-tight-blue-jeans-on-white-background.jpg?s=612x612&w=0&k=20&c=HsI-xC12KkzjeCaFC4eQ33SZuL53EerbfLMkPuLpaVw=", "quantity": 2}]	298000	PENDING	t	Administrador	\N	\N	2026-05-05 23:06:43.373	2026-05-05 23:06:43.373
cmot8p0ok000hrv08tqr067b6	cmot619x20000q2yshsvxexxr	[{"id": "chaqueta-bomber-invierno", "name": "Chaqueta Bomber Invierno", "price": 199000, "imageUrl": "https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2", "quantity": 1}]	199000	CANCELLED	t	ssss	1213123	\N	2026-05-05 23:08:29.493	2026-05-05 23:08:45.968
cmot8ro46000jrv08vrigcb0q	cmot619x20000q2yshsvxexxr	[{"id": "sandalias-tacon-gris", "name": "Sandalias de Tacón Gris", "price": 179000, "imageUrl": "https://www.piccolashoes.com/cdn/shop/products/joyce-grey-open-toe-heels.png?v=1761084095&width=1024", "quantity": 1}]	179000	CONFIRMED	t	Administrador	\N	\N	2026-05-05 23:10:33.175	2026-05-05 23:12:18.882
cmot9c6w3000trv083jbnhykh	cmot752uj0000q2rg81ndfhdm	[{"id": "chaqueta-bomber-invierno", "name": "Chaqueta Bomber Invierno", "price": 199000, "imageUrl": "https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2", "quantity": 1}]	199000	PENDING	t	aa	ss	\N	2026-05-05 23:26:30.627	2026-05-05 23:26:30.627
cmot9e9m8000vrv08v1j3adp0	cmot752uj0000q2rg81ndfhdm	[{"id": "jeans-slim-fit-azul", "name": "Jeans Slim Fit Azul", "price": 149000, "imageUrl": "https://media.istockphoto.com/id/173239968/photo/skinny-tight-blue-jeans-on-white-background.jpg?s=612x612&w=0&k=20&c=HsI-xC12KkzjeCaFC4eQ33SZuL53EerbfLMkPuLpaVw=", "quantity": 1}]	149000	PENDING	t	Test User	\N	\N	2026-05-05 23:28:07.473	2026-05-05 23:28:07.473
cmot9eocv000xrv08r0k03tz9	cmot752uj0000q2rg81ndfhdm	[{"id": "chaqueta-bomber-invierno", "name": "Chaqueta Bomber Invierno", "price": 199000, "imageUrl": "https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2", "quantity": 1}]	199000	PENDING	t	Test User	\N	\N	2026-05-05 23:28:26.576	2026-05-05 23:28:26.576
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, name, description, price, "originalPrice", discount, rating, "soldCount", stock, "imageUrl", "isActive", "isFlashSale", "categoryId", "createdAt", "updatedAt") FROM stdin;
camiseta-algodon-casual	Camiseta de Algodón Casual	Camiseta de algodón 100% premium, corte regular y tacto suave. Ideal para uso diario, combinable con cualquier outfit casual o deportivo.	59000	89000	34	4.7	210	50	https://skims.imgix.net/s/files/1/0259/5448/4284/files/SKIMS-LOUNGEWEAR-TP-TSH-5701M-CHK.jpg?v=1738175705&auto=format&q=70&ixlib=react-9.11.0	t	t	cmot619xh0006q2ysvnyv792q	2026-05-05 21:54:02.515	2026-05-05 21:54:02.515
chaqueta-bomber-invierno	Chaqueta Bomber Invierno	Chaqueta bomber con forro térmico, perfecta para los días fríos. Diseño moderno y resistente al viento, con bolsillos cómodos.	199000	320000	38	4.5	145	30	https://cdn11.bigcommerce.com/s-luvww1semp/images/stencil/1280x1280/products/2194/13860/alvin-gybk%2520%281%29__81511.1752590280.jpg?c=2	t	t	cmot619xj0007q2ysh3stmnd3	2026-05-05 21:54:02.518	2026-05-05 21:54:02.518
camisa-elegante-rayas	Camisa Elegante a Rayas	Camisa de manga larga, ajuste slim, tejido transpirable. Ideal para oficina y eventos casuales-formales. Confección de alta calidad.	129000	179000	28	4.6	188	40	http://www.nimble-made.com/cdn/shop/products/new-striped-blue-white-dress-shirt_9bf4f99c-3308-4910-b57a-d118fb953134.jpg?v=1670899180	t	f	cmot619xl0008q2ysnrntrivq	2026-05-05 21:54:02.521	2026-05-05 21:54:02.521
jeans-slim-fit-azul	Jeans Slim Fit Azul	Jeans de mezclilla premium, corte slim fit, color azul medio. Material elástico para mayor comodidad durante todo el día.	149000	220000	32	4.4	320	60	https://media.istockphoto.com/id/173239968/photo/skinny-tight-blue-jeans-on-white-background.jpg?s=612x612&w=0&k=20&c=HsI-xC12KkzjeCaFC4eQ33SZuL53EerbfLMkPuLpaVw=	t	t	cmot619xo0009q2yshlbl7sbx	2026-05-05 21:54:02.523	2026-05-05 21:54:02.523
bolso-tote-cuero	Bolso Tote de Cuero	Bolso tote elegante en cuero genuino, espacioso y resistente. Ideal para oficina, viajes o uso diario. Acabados de lujo.	289000	450000	36	4.8	95	25	https://latelierglobal.com/cdn/shop/products/olimpia-leather-tote-608292.jpg?v=1737917924&width=2048	t	f	cmot619xq000aq2ysyj5hg4ra	2026-05-05 21:54:02.526	2026-05-05 21:54:02.526
zapatillas-blancas-clasicas	Zapatillas Blancas Clásicas	Zapatillas blancas atemporales, suela de goma antideslizante, plantilla acolchada. Combinan con todo, máxima comodidad.	169000	249000	32	4.6	412	80	https://nothingnew.com/cdn/shop/products/1024x1024-Mens-Unoriginal-White-090222-3.4_1024x1024.jpg?v=1664821005	t	t	cmot619xs000bq2ys5a8na0qv	2026-05-05 21:54:02.528	2026-05-05 21:54:02.528
oxford-cuero-negro	Zapatos Oxford de Cuero Negro	Zapatos Oxford clásicos en cuero genuino negro, perfectos para ocasiones formales. Confección artesanal y durabilidad superior.	259000	380000	32	4.7	132	35	https://taftclothing.com/cdn/shop/products/Jack_Black_cropped.jpg?v=1762439486&width=1000	f	f	cmot619xs000bq2ys5a8na0qv	2026-05-05 21:54:02.53	2026-05-05 23:04:09.421
sandalias-tacon-gris	Sandalias de Tacón Gris	Sandalias elegantes con tacón cómodo de 7cm, color gris claro versátil. Perfectas para eventos especiales y looks sofisticados.	179000	270000	34	4.3	86	5	https://www.piccolashoes.com/cdn/shop/products/joyce-grey-open-toe-heels.png?v=1761084095&width=1024	t	f	cmot619xs000bq2ys5a8na0qv	2026-05-05 21:54:02.531	2026-05-05 23:09:53.617
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Setting" (id, key, value, "createdAt", "updatedAt") FROM stdin;
cmot619xa0003q2yscmqkuqti	storeName	EcomDash	2026-05-05 21:54:02.495	2026-05-05 23:15:39.042
cmot619xe0005q2ysx0cbsjs6	currency	COP	2026-05-05 21:54:02.499	2026-05-05 23:15:39.042
cmot619x80002q2ys1k0rn4fz	whatsappNumber	573044444261	2026-05-05 21:54:02.492	2026-05-05 23:15:39.043
cmot619xc0004q2ysuxbzvl3a	paymentMethod	whatsapp	2026-05-05 21:54:02.497	2026-05-05 23:15:39.043
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "passwordHash", role, "createdAt", "updatedAt") FROM stdin;
cmot619x20000q2yshsvxexxr	Administrador	admin@ecomdash.com	$2a$10$wQBYHDeXFY9KL5xv.5TFueJfZzrKJhVMhe444LKOMJ7L8JvSeI1.2	SUPERADMIN	2026-05-05 21:54:02.486	2026-05-05 21:54:02.486
cmot6bc320000q2ay9ygeinba	Test User	testuserfxbj6tmr@example.com	$2a$10$zRJyR8pch6zviRRs/91h1e2NxEerHmY7O.12d9uAOuCVvenshpn/e	CLIENTE	2026-05-05 22:01:51.854	2026-05-05 22:01:51.854
cmot6envh0000q2wed109htia	Test User	testusero452o64e@example.com	$2a$10$EohZrzIYDERkyb3gqOpnJOMbpgHtGY1poO.m5E9ogHUedWuyvGY7K	CLIENTE	2026-05-05 22:04:27.101	2026-05-05 22:04:27.101
cmot619x60001q2ysc4tedbjk	John Doe	john@doe.com	$2a$10$wQBYHDeXFY9KL5xv.5TFueJfZzrKJhVMhe444LKOMJ7L8JvSeI1.2	ADMIN	2026-05-05 21:54:02.49	2026-05-05 22:50:55.706
cmot752uj0000q2rg81ndfhdm	Test User	testuserczf7e2ud@example.com	$2a$10$wQBYHDeXFY9KL5xv.5TFueJfZzrKJhVMhe444LKOMJ7L8JvSeI1.2	CLIENTE	2026-05-05 22:24:59.563	2026-05-05 22:24:59.563
\.


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (id);


--
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Category_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Category_slug_key" ON public."Category" USING btree (slug);


--
-- Name: Order_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Order_status_idx" ON public."Order" USING btree (status);


--
-- Name: Order_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Order_userId_idx" ON public."Order" USING btree ("userId");


--
-- Name: Product_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_categoryId_idx" ON public."Product" USING btree ("categoryId");


--
-- Name: Product_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_isActive_idx" ON public."Product" USING btree ("isActive");


--
-- Name: Setting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Setting_key_key" ON public."Setting" USING btree (key);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Order Order_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Product Product_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--


