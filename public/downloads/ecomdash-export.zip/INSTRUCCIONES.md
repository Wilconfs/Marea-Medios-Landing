# 📦 EcomDash – Manual de Instalación y Despliegue

EcomDash es una tienda online completa con catálogo público, carrito, checkout y panel administrativo (productos, categorías, pedidos, usuarios y configuración).

Esta guía te explica paso a paso cómo:

1. Ejecutar el proyecto **localmente** en tu computador.
2. Desplegarlo en **Hostinger** (Cloud Hosting / VPS con Node.js + PostgreSQL).
3. Restaurar la **base de datos** con datos de ejemplo.

---

## 🧰 Prerrequisitos

Antes de empezar necesitas tener instalado:

- **Node.js 18.18 o superior** ([descargar](https://nodejs.org/))
- **PostgreSQL 14 o superior** ([descargar](https://www.postgresql.org/download/))
- **Yarn 1.x** (recomendado): `npm install -g yarn`
- Editor de código (VS Code recomendado)
- Cliente de terminal (bash, zsh, PowerShell o cmd)

> 💡 También puedes usar `npm` en lugar de `yarn`, solo reemplaza `yarn` por `npm run` en los comandos.

---

## 📁 Contenido del paquete

```
ecomdash-export/
├── ecomdash/                     ← Código fuente del proyecto
│   ├── app/                      ← Páginas (Next.js App Router)
│   ├── components/               ← Componentes React reutilizables
│   ├── lib/                      ← Utilidades, autenticación, conexión BD
│   ├── prisma/
│   │   └── schema.prisma         ← Modelo de la base de datos
│   ├── public/                   ← Imágenes y assets estáticos
│   ├── scripts/
│   │   ├── seed.ts               ← Datos completos (borra y recarga todo)
│   │   └── safe-seed.ts          ← Datos seguros (no borra existentes)
│   ├── .env.example              ← Plantilla de variables de entorno
│   ├── package.json              ← Dependencias y scripts
│   └── next.config.js
├── database/
│   └── ecomdash_dump.sql         ← Respaldo SQL listo para restaurar
└── INSTRUCCIONES.md              ← Este archivo
```

---

## 🖥️ Parte 1 – Ejecución local

### Paso 1 · Crear la base de datos PostgreSQL

Abre tu terminal con un usuario que tenga permisos de PostgreSQL.

**Opción A · Crear desde la terminal (Linux/macOS):**

```bash
sudo -u postgres psql
```

Y dentro del prompt de psql ejecuta:

```sql
CREATE DATABASE ecomdash;
CREATE USER ecomdash_user WITH PASSWORD 'mi_password_seguro';
GRANT ALL PRIVILEGES ON DATABASE ecomdash TO ecomdash_user;
\c ecomdash
GRANT ALL ON SCHEMA public TO ecomdash_user;
\q
```

**Opción B · Crear desde pgAdmin (Windows / interfaz gráfica):**

1. Abre **pgAdmin**.
2. Click derecho en *Databases* → *Create* → *Database…*
3. Nombre: `ecomdash` → Save.

---

### Paso 2 · Configurar el archivo `.env`

```bash
cd ecomdash
cp .env.example .env
```

Edita `.env` con tus datos reales:

```env
DATABASE_URL="postgresql://ecomdash_user:mi_password_seguro@localhost:5432/ecomdash"
NEXTAUTH_SECRET="genera-uno-con-openssl-rand-base64-32"
NEXTAUTH_URL="http://localhost:3000"
```

**Genera un secreto fuerte:**

```bash
# Linux / macOS
openssl rand -base64 32

# Windows PowerShell
[Convert]::ToBase64String((1..32 | %{ Get-Random -Maximum 256 }))
```

Copia el resultado y pégalo en `NEXTAUTH_SECRET`.

---

### Paso 3 · Instalar dependencias

```bash
yarn install
```

Esto descargará todos los paquetes en `node_modules/` (puede tardar 1-3 min).

---

### Paso 4 · Cargar datos en la base de datos

Tienes **dos opciones**, escoge la que prefieras:

#### 🟢 Opción A · Restaurar el respaldo SQL (RECOMENDADO)

Importa el dump con datos reales (productos, categorías, usuarios, configuración):

```bash
# Linux/macOS
psql -U ecomdash_user -d ecomdash -f ../database/ecomdash_dump.sql

# Windows (CMD)
psql -U ecomdash_user -d ecomdash -f ..\database\ecomdash_dump.sql
```

Si te pide contraseña, escribe la que definiste en el Paso 1.

> ✅ Esta opción te deja la BD lista con catálogo, usuarios y configuración demo.

#### 🔵 Opción B · Crear esquema vacío + sembrar datos básicos

```bash
yarn db:generate          # Genera el cliente Prisma
yarn db:push              # Crea las tablas en PostgreSQL
yarn db:seed              # Inserta datos de ejemplo
```

> Útil si quieres empezar desde cero o si la Opción A te da error.

#### ⚡ Opción C · Setup automático (todo en uno)

```bash
yarn setup
```

Este comando hace `install + db:generate + db:push + db:seed` en una sola línea.

---

### Paso 5 · Iniciar el servidor de desarrollo

```bash
yarn dev
```

Abre tu navegador en: **http://localhost:3000**

Tu tienda EcomDash ya está funcionando. 🎉

---

### Paso 6 · Acceso al panel de administración

Ve a **http://localhost:3000/admin** o haz clic en *Iniciar sesión* y entra con:

| Rol | Email | Contraseña |
|-----|-------|------------|
| **Administrador** | `admin@ecomdash.com` | `admin123` |
| **Cliente demo** | `test@test.com` | `test1234` |

> ⚠️ **Cambia estas contraseñas antes de poner la tienda en producción.** Puedes hacerlo desde el panel: *Admin → Usuarios → Editar*.

---

## 🌐 Parte 2 – Despliegue en Hostinger

EcomDash funciona en planes **Cloud Hosting**, **VPS** o **Premium Web Hosting** que soporten Node.js + PostgreSQL.

### Paso 1 · Crear la base de datos PostgreSQL en hPanel

1. Inicia sesión en tu cuenta de Hostinger → **hPanel**.
2. Ve a **Bases de datos → PostgreSQL**.
3. Crea una nueva base de datos. Anota:
   - Nombre de la BD (ej: `u123456_ecomdash`)
   - Usuario (ej: `u123456_admin`)
   - Contraseña
   - Host (normalmente `127.0.0.1` o un host específico que te asigne)
   - Puerto (normalmente `5432`)

### Paso 2 · Importar el respaldo a Hostinger

**Opción A · Vía phpPgAdmin / Adminer en hPanel:**

1. En *Bases de datos → PostgreSQL* abre el panel de gestión.
2. Selecciona la base de datos.
3. Pestaña *Importar* → sube `database/ecomdash_dump.sql` → Ejecutar.

**Opción B · Vía SSH (VPS o Cloud):**

```bash
psql -h 127.0.0.1 -U u123456_admin -d u123456_ecomdash -f ecomdash_dump.sql
```

### Paso 3 · Subir el código a Hostinger

**Opción A · Cloud Hosting con Git:**

1. hPanel → **Git** → conecta tu repositorio (GitHub, GitLab).
2. Selecciona la rama y la ruta de despliegue.
3. Hostinger clonará el código automáticamente.

**Opción B · FTP (FileZilla, WinSCP):**

1. Sube **toda la carpeta `ecomdash/`** al directorio raíz de tu hosting (normalmente `public_html/`).
2. **No subas** `node_modules`, `.next`, `.env`, `.git`.

**Opción C · VPS con SSH:**

```bash
# Comprime localmente
tar czf ecomdash.tar.gz ecomdash/

# Sube al VPS
scp ecomdash.tar.gz usuario@tu-vps:/home/usuario/

# En el VPS
ssh usuario@tu-vps
tar xzf ecomdash.tar.gz
cd ecomdash
```

### Paso 4 · Configurar Node.js en hPanel

1. hPanel → **Avanzado → Node.js**.
2. *Crear aplicación*:
   - **Versión Node.js:** 18.x o superior
   - **Modo de aplicación:** Production
   - **Raíz de la aplicación:** `/home/u123456/public_html/ecomdash` (o donde subiste el código)
   - **URL de la aplicación:** tu dominio o subdominio
   - **Archivo de inicio:** `node_modules/next/dist/bin/next` con argumento `start`
3. **Variables de entorno** (sección *Environment variables*):
   - `DATABASE_URL` → con los datos del Paso 1
   - `NEXTAUTH_SECRET` → un string aleatorio de 32+ chars
   - `NEXTAUTH_URL` → tu URL pública (ej: `https://mitienda.com`)
   - `NODE_ENV=production`
4. Guarda la configuración.

### Paso 5 · Instalar dependencias y construir

Desde la terminal SSH o desde el botón *Run NPM Install* del panel Node.js:

```bash
cd /home/u123456/public_html/ecomdash
npm install        # o yarn install
npx prisma generate
npm run build      # o yarn build
```

### Paso 6 · Iniciar la aplicación

Desde el panel Node.js de hPanel haz clic en **Restart** o ejecuta:

```bash
npm start          # o yarn start
```

Tu tienda estará disponible en la URL configurada. 🚀

---

## 🧪 Verificación final

Una vez desplegado, abre tu navegador y verifica:

- [ ] **Landing pública** carga el catálogo de productos.
- [ ] **Login** funciona con `admin@ecomdash.com / admin123`.
- [ ] **Panel admin** muestra el dashboard con métricas.
- [ ] **CRUD de productos** permite crear/editar/eliminar.
- [ ] **Carrito** y **checkout** funcionan.
- [ ] **WhatsApp** redirige correctamente al número configurado.

---

## 🛠️ Solución de problemas comunes

### ❌ Error: `Can't reach database server`

- Verifica que PostgreSQL esté corriendo: `sudo systemctl status postgresql`
- Revisa que `DATABASE_URL` tenga las credenciales correctas.
- Si usas Hostinger: confirma que el host sea `127.0.0.1` y el puerto `5432`.

### ❌ Error: `NEXTAUTH_SECRET is not set`

- Asegúrate de tener un valor en `.env` para esa variable.
- En Hostinger: añádela en *Variables de entorno* del panel Node.js.

### ❌ Error de Prisma `P1001` o `P3009`

```bash
yarn db:generate
yarn db:push
```

### ❌ La página muestra error 500

- Mira los logs del servidor:
  - Local: la terminal donde ejecutaste `yarn dev`.
  - Hostinger: hPanel → Node.js → *Logs*.

### ❌ El puerto 3000 ya está en uso

```bash
# Linux/macOS
PORT=3001 yarn dev

# Windows
set PORT=3001 && yarn dev
```

### ❌ `prisma db push` falla con permisos

Conecta como superusuario y otorga permisos:

```sql
GRANT ALL ON SCHEMA public TO ecomdash_user;
```

---

## 📚 Comandos útiles del proyecto

| Comando | Descripción |
|---------|-------------|
| `yarn dev` | Servidor de desarrollo (hot reload) |
| `yarn build` | Construye la versión de producción |
| `yarn start` | Inicia el servidor en producción |
| `yarn db:generate` | Regenera el cliente de Prisma |
| `yarn db:push` | Sincroniza el esquema con la BD |
| `yarn db:seed` | Inserta datos de ejemplo |
| `yarn db:studio` | Abre Prisma Studio (admin de BD visual) |
| `yarn db:reset` | ⚠️ Borra y recrea toda la BD |
| `yarn setup` | Hace install + generate + push + seed |
| `yarn lint` | Revisa el código con ESLint |

---

## 🗂️ Estructura técnica resumida

```
ecomdash/
├── app/
│   ├── (public)/              ← Tienda pública (catálogo, carrito, checkout)
│   ├── admin/                 ← Panel administrativo
│   ├── api/                   ← Endpoints de API REST
│   └── auth/                  ← Login y registro
├── components/
│   ├── ui/                    ← Componentes shadcn/ui (botones, inputs, etc.)
│   ├── public/                ← Componentes de la tienda
│   └── admin/                 ← Componentes del panel
├── lib/
│   ├── auth.ts                ← Configuración NextAuth
│   ├── db.ts                  ← Cliente Prisma (singleton)
│   ├── store/                 ← Estado global Zustand (carrito)
│   └── utils.ts
├── prisma/
│   └── schema.prisma          ← User, Product, Category, Order, OrderItem, Setting
└── scripts/
    ├── seed.ts                ← Carga inicial completa
    └── safe-seed.ts           ← Carga incremental (segura)
```

### Stack técnico

- **Framework:** Next.js 14 (App Router)
- **Lenguaje:** TypeScript
- **Base de datos:** PostgreSQL + Prisma ORM
- **Autenticación:** NextAuth.js (sesiones con JWT)
- **UI:** Tailwind CSS + shadcn/ui (Radix UI)
- **Estado:** Zustand (carrito) + React state local
- **Gráficas:** Recharts

---

## 🆘 ¿Necesitas ayuda?

Si tienes dudas durante la instalación:

1. Revisa la sección **Solución de problemas** arriba.
2. Verifica que las versiones de Node.js y PostgreSQL cumplan los requisitos.
3. Asegúrate de que las variables de `.env` sean correctas.

> 💡 **Tip:** En el primer arranque local, si todo está bien configurado, deberías ver: `▲ Next.js 14.2.x · Local: http://localhost:3000` en tu terminal.

---

¡Listo! Ya tienes tu tienda **EcomDash** corriendo. 🛒✨
