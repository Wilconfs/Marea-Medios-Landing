// server/index.ts
import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
async function startServer() {
  const app = express();
  const server = createServer(app);
const staticPath = 
path.resolve(__dirname, "public");  
app.use(express.static(staticPath));

app.get(/^(?!\/assets).*/, (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
});
  const port = process.env.PORT || 3e3;
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
startServer().catch(console.error);
